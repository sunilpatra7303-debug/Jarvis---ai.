const $ = (id) => document.getElementById(id);
const micButton = $("micButton");
const language = $("language");
let recognition = null;
let busy = false;

const phrases = {
  hi: {
    hello: "Namaste! Main JARVIS hoon. Abhi mera demo mode chal raha hai. Real AI brain agle step mein connect karenge.",
    time: () => "Main abhi phone ka exact time access nahi kar raha. Apne phone ke status bar mein time dekh sakte hain.",
    help: "Aap mujhse Hindi, English ya Odia mein baat kar sakte hain. Abhi voice input aur demo replies available hain."
  },
  en: {
    hello: "Hello! I am JARVIS. Demo mode is active. We will connect the real AI brain in the next step.",
    time: () => "I do not have live device data connected yet. Please check your phone clock.",
    help: "You can speak to me in Hindi, English or Odia. Voice input and demo replies are available now."
  },
  or: {
    hello: "ନମସ୍କାର! ମୁଁ JARVIS। ବର୍ତ୍ତମାନ ଡେମୋ ମୋଡ୍ ଚାଲୁଛି। ପରବର୍ତ୍ତୀ ପଦକ୍ଷେପରେ ଆମେ AI କନେକ୍ଟ କରିବା।",
    time: "ମୋ ପାଖରେ ଏପର୍ଯ୍ୟନ୍ତ ଫୋନ୍‌ର ସମୟ ତଥ୍ୟ ନାହିଁ।",
    help: "ଆପଣ ମୋ ସହିତ ହିନ୍ଦୀ, ଇଂରାଜୀ କିମ୍ବା ଓଡ଼ିଆରେ କଥା ହୋଇପାରିବେ।"
  }
};

function detectGroup(text) {
  if (/[଀-୿]/.test(text)) return "or";
  if (/[ऀ-ॿ]/.test(text)) return "hi";
  return language.value === "or-IN" ? "or" : language.value === "hi-IN" ? "hi" : "en";
}
function setStatus(text, state="ready") {
  $("statusText").textContent = text.toUpperCase();
  $("systemState").textContent = state === "listening" ? "● LISTENING" : state === "thinking" ? "● PROCESSING" : "● SYSTEM READY";
}
function speak(text, lang=language.value) {
  if (!("speechSynthesis" in window)) return;
  speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = lang;
  utterance.rate = 0.95;
  speechSynthesis.speak(utterance);
}
function replyTo(text) {
  const group = detectGroup(text);
  const lower = text.toLowerCase();
  let answer;
  if (/hello|hi jarvis|hey jarvis|नमस्ते|हेलो|ନମସ୍କାର/i.test(lower)) answer = phrases[group].hello;
  else if (/time|समय|କେତେ ବାଜିଲା/i.test(lower)) answer = typeof phrases[group].time === "function" ? phrases[group].time() : phrases[group].time;
  else if (/help|मदद|ସାହାଯ୍ୟ/i.test(lower)) answer = phrases[group].help;
  else answer = group === "hi"
    ? "Maine aapki baat sun li: " + text + ". Abhi main demo mode mein hoon. Real AI connect karne ke baad iska intelligent jawab dunga."
    : group === "or"
      ? "ମୁଁ ଆପଣଙ୍କ କଥା ଶୁଣିଲି: " + text + "। ମୁଁ ଏବେ ଡେମୋ ମୋଡ୍‌ରେ ଅଛି।"
      : "I heard: " + text + ". I am in demo mode for now. We will connect the full AI brain next.";
  $("heardText").textContent = text;
  $("userLine").hidden = false;
  $("reply").textContent = answer;
  setStatus("Speaking", "thinking");
  speak(answer);
  if ("speechSynthesis" in window) speechSynthesis.onvoiceschanged = () => {};
  setTimeout(() => setStatus("Awaiting command"), 700);
}
function startListening() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    $("reply").textContent = "Speech recognition is not available in this browser. Try updated Google Chrome and use the text box below.";
    return;
  }
  if (busy) return;
  recognition = new SpeechRecognition();
  recognition.lang = language.value;
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
  recognition.onstart = () => { busy = true; micButton.classList.add("listening"); $("hint").textContent = "LISTENING..."; setStatus("Listening", "listening"); };
  recognition.onresult = (event) => replyTo(event.results[0][0].transcript);
  recognition.onerror = (event) => { $("reply").textContent = "Microphone error: " + event.error + ". Check microphone permission and internet connection."; };
  recognition.onend = () => { busy = false; micButton.classList.remove("listening"); $("hint").textContent = "TAP TO SPEAK"; setStatus("Awaiting command"); };
  try { recognition.start(); } catch (e) { $("reply").textContent = "Could not start microphone. Please try again."; }
}
micButton.addEventListener("click", startListening);
$("sendButton").addEventListener("click", () => {
  const value = $("messageInput").value.trim();
  if (!value) return;
  $("messageInput").value = "";
  replyTo(value);
});
$("messageInput").addEventListener("keydown", (e) => { if (e.key === "Enter") $("sendButton").click(); });
language.addEventListener("change", () => {
  const names = {"hi-IN":"Hindi","en-IN":"English","or-IN":"Odia"};
  $("reply").textContent = "Voice language set to " + names[language.value] + ".";
});
